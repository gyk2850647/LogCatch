# from ctypes import *
import os
import sys
import ftplib
import time
#import subprocess
import datetime
import shutil
import re
import random
from tkinter import *
# from PIL import ImageTk, Image

global time_used


class Log_catch_GUI(Frame):
    def __init__(self, root):
        root.title("抓Log包")
        # root.iconbitmap('logo_og_USz_icon.ico')
        self.canvas = Canvas(root, bg='white', width=550, heigh=400)
        self.canvas.pack(fill="x")
        # self.imgpath = 'download.jpg'
        # self.img = Image.open(self.imgpath)

        # self.photo = ImageTk.PhotoImage(self.img)
        # imgLabel = Label(root,image=self.photo)#把图片整合到标签类中
        # imgLabel.pack(anchor=CENTER)
        # self.canvas.create_image(150,170,image = self.photo)
        # self.canvas.pack()

        font1 = "黑体", 30, "bold"
        self.lblTime = Label(root, text="Time(时间)",
                             font=font1, bg='white', fg='blue')
        self.txtName = Label(root, text="",
                             font=font1, bg='white', fg='blue')
        self.lblTime.place(x=175, y=15)
        self.txtName.place(x=175, y=55)
        self.btnSave = Button(root, text='Start(开始)', command=self.__btnStart_clicked, fg='red', font=font1,
                              relief=SOLID, borderwidth=1)
        self.btnSave.place(x=10, y=200)
        self.btnClear = Button(root, text='Stop(结束)', command=self.__btnStop_clicked, fg='red', font=font1,
                               relief=SOLID, borderwidth=1)
        self.btnClear.place(x=300, y=200)
        self.btnBreak_Point = Button(root, text='Break Point(断点)', command=self.__btnBreak_Point_clicked, fg='red',
                                     font=font1, relief=SOLID, borderwidth=1)
        self.btnBreak_Point.place(x=90, y=125)
        self.btnExit = Button(root, text='Exit(退出)', command=self.__btnExit_clicked, fg='red', font=font1, relief=SOLID,
                              borderwidth=1)
        self.btnExit.place(x=150, y=270)
        self.btnSave.config(state='normal')
        self.btnClear.config(state='disable')
        self.btnBreak_Point.config(state='normal')
        self.time_checker = True

    def __btnStart_clicked(self):
        try:
            self.time_checker = False
            changefilename()
            time.sleep(1)
            # strftime()函数根据指定格式返回可读字符串表示的时间
            self.__start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            # strptime()函数根据指定的格式把一个时间字符串解析为时间元组
            self.__start_time = datetime.datetime.strptime(
                self.__start_time, "%Y-%m-%d %H:%M:%S")
            self.__start_time = int(self.__start_time.timestamp())
            self.__update_time()
            self.btnSave.config(state='disable')
            self.btnClear.config(state='normal')
            self.btnBreak_Point.config(state='disable')
        except Exception as msg:
            print("Error - ", msg)

    def __update_time(self):
        if self.time_checker == False:
            self.txtName.config(
                text=str(int(time.time()) - self.__start_time) + 's(秒)')
            self.txtName.after(1000, self.__update_time)

    def __btnStop_clicked(self):
        try:
            self.time_checker = True
            self.__now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.__now_time = datetime.datetime.strptime(
                self.__now_time, "%Y-%m-%d %H:%M:%S")
            self.__now_time = int(self.__now_time.timestamp())
            time_used = self.__now_time - self.__start_time

            print('结束时间戳为：', self.__now_time)
            print('开始时间戳为：', self.__start_time)
            time_used = self.__now_time - self.__start_time
            self.txtName.config(text=str(time_used) + 's(秒)')
            outfile = open('time_used.txt', 'w')
            outfile.write(str(time_used))
            outfile.close()
            self.btnSave.config(state='normal')
            self.btnClear.config(state='disable')
            self.btnBreak_Point.config(state='normal')

            print('获取日志总时长为：%d (秒)' % time_used)
            call()

            return (time_used)
        except Exception as msg:
            print("Error - ", msg)

    def __btnBreak_Point_clicked(self):
        changefilename()

    def __btnExit_clicked(self):
        sys.exit()


class myFtp:
    ftp = ftplib.FTP()  # 实例化ftp对象
    # force encoding for file name in utf-8 rather than default that is iso-8889-1
    ftp.encoding = 'gbk'
    bIsDir = False
    path = ""

    def __init__(self, host, port=int(21)):
        # self.ftp.set_debuglevel(2) #打开调试级别2，显示详细信息
        self.ftp.set_pasv(0)  # 0主动模式 1 #被动模式
        self.ftp.connect(host, port)  # 连接

    def Login(self, user, passwd):
        self.ftp.login(user, passwd)  # 登录，如果匿名登录则用空串代替即可
        print(self.ftp.welcome)

    def DownLoadFile(self, LocalFile, RemoteFile, file_address):
        file_handler = open(LocalFile, 'wb')  # 以二进制格式只写的方式在本地打开文件
        self.ftp.cwd(file_address)  # 进入远程目录，设置当前操做目录为path，
        self.ftp.retrbinary("RETR %s" % (RemoteFile),
                            file_handler.write, 4096)  # 下载服务器上文件并以二进制形式写入本地
        file_handler.close()
        print('远程文件下载完成。')
        return True

    def UpLoadFile(self, LocalFile, RemoteFile):
        # os.path.isfile()函数判断路径是否为文件
        if os.path.isfile(LocalFile) == False:
            return False
        file_handler = open(LocalFile, "rb")  # 以二进制格式只读的方式在本地打开文件
        self.ftp.storbinary('STOR %s' % RemoteFile,
                            file_handler, 4096)  # 上传二进制文件
        file_handler.close()
        return True

    def UpLoadFileTree(self, LocalDir, RemoteDir):
        # os.path.isdir()函数判断路径是否为目录
        if os.path.isdir(LocalDir) == False:
            return False
        print("LocalDir:", LocalDir)
        # os.listdir()函数返回指定文件夹包含的文件或文件夹的名字的列表
        LocalNames = os.listdir(LocalDir)
        print("list:", LocalNames)
        print(RemoteDir)
        self.ftp.cwd(RemoteDir)  # 设置当前工作目录为path
        for Local in LocalNames:
            # os.path.join()函数把目录和文件名合成一个路径
            src = os.path.join(LocalDir, Local)
            if os.path.isdir(src):
                self.UpLoadFileTree(src, Local)
            else:
                self.UpLoadFile(src, Local)

        self.ftp.cwd("..")
        return

    def DownLoadFileTree(self, LocalDir, RemoteDir):
        print("remoteDir:", RemoteDir)
        if os.path.isdir(LocalDir) == False:
            os.makedirs(LocalDir)
        self.ftp.cwd(RemoteDir)  # 设置当前工作目录为path
        # 获取目录下的文件返回一个文件名的列表，赋值给RemoteNames
        RemoteNames = self.ftp.nlst()
        print("RemoteNames", RemoteNames)
        print(self.ftp.nlst("/del1"))
        for file in RemoteNames:
            Local = os.path.join(RemoteDir, file)
            if self.isDir(Local):
                self.DownLoadFileTree(Local, file)
            else:
                self.DownLoadFile(Local, file, RemoteDir)
        self.ftp.cwd("..")
        return

    def show(self, list):
        result = list.lower().split(" ")
        if self.path in result and "<dir>" in result:
            self.bIsDir = True

    def isDir(self, path):
        self.bIsDir = False
        self.path = path
        # this ues callback function ,that will change bIsDir value
        self.ftp.retrlines('LIST', self.show)
        return self.bIsDir

    def close(self):
        self.ftp.quit()  # 关闭连接并退出

    # highThird代表最大版本号码第三位，highFouth代表最大版本号码第四位
    def max_vsesion(self, highThird, highFouth):
        '''

        :param ftp: ftp对象
        :return: 最大版本号码
        '''
        self.ftp.cwd("/SmartOne SPX/2.7SP每日构建")
        file_list = self.ftp.nlst()
        tmp_list = []
        for files in file_list:
            try:
                if (files.endswith(".exe")) and (int(self.ftp.size(files) / 1024 / 1024) < 700):
                    tmp_list.append(files)
            except ftplib.error_perm:
                print('ftp出错,断开ftp连接')
                self.ftp.close()
                print('等待10s')
                time.sleep(10)
                continue

        # print(tmp_list)

        # tmplist1,为版本号list
        # high_11为第三位版本号最大值（位置-11）
        high_11 = 0
        tmp_list1 = []
        for i in range(0, len(tmp_list)):
            for i in tmp_list:
                if high_11 < int(i[-11]):
                    high_11 = int(i[-11])
        for i in tmp_list:
            if int(i[-11]) == high_11:
                tmp_list1.append(i)
        # high_9为第四段版本号最大值（位置-9--4）
        high_9 = 0
        tmp_list2 = []
        for i in range(0, len(tmp_list1)):
            for i in tmp_list1:
                if high_9 < int(i[-9:-4]):
                    high_9 = int(i[-9:-4])

        for i in tmp_list:
            if int(i[-9:-4]) == high_9:
                tmp_list2.append(i)

        if int(tmp_list2[0][-9:-4]) == int(highFouth):
            return True
        else:
            return tmp_list2

    def time_range_file(self, seconds, file_address):
        # Check_address = False
        # while Check_address == True:
        # try:
        # file_address = str(input("What's the file address?(文件位置:/xxxx/xxxx)"))
        # self.ftp.cwd(file_address)
        # Check_address = True
        # except:
        # print("Adress error文件位置错误")'
        self.ftp.cwd(file_address)
        Check_address = True
        file_list = self.ftp.nlst()
        tmp_list = []
        # file_address = '/test'
        data = []
        download = []
        self.ftp.dir(data.append)
        # Check_minutes = False
        # while Check_minutes == False:
        # minutes = float(input("How many minutes' files you want to get?需要几分钟内文件 "))
        # Check_minutes = True
        times = 0
        for line in data:
            for i in range(times, len(file_list)):
                col = line.split()  # 用，分割
                datestr = ' '.join(line.split()[0:2])
                date = time.strptime(datestr, '%m-%d-%y %I:%M%p')
                timeStamp = int(time.mktime(date))
                nowtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                nowtime = datetime.datetime.strptime(
                    nowtime, "%Y-%m-%d %H:%M:%S")
                nowtimeStamp = int(nowtime.timestamp())
                # print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                # print(line)
                # print(file_list[i])
                # print(nowtimeStamp-timeStamp)
                if nowtimeStamp - timeStamp <= seconds:
                    if file_list[i] in download:
                        break
                    else:
                        download.append(file_list[i])
                times += 1
                break
        # print(download)
        return download

        # try:

        # except ftplib.error_perm:
        # print('ftp出错,断开ftp连接')
        # self.ftp.close()
        # print('等待10s')
        # time.sleep(10)
        # continue

    def changename(self, path, change_name):
        self.ftp.rename(path, change_name)


class local:
    def copyfile(src, dst):
        shutil.copy(src, dst)


def mkdir(path):  # 创建目录函数
    # 引入模块
    import os

    # 去除首位空格
    path = path.strip()
    # 去除尾部 \ 符号
    path = path.rstrip("\\")

    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)

    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)

        print(path + ' 目录创建成功，写入文件。')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(path + ' 目录已存在，覆盖写入新文件。')
        return False


def call():
    print('开始下载日志文件！！！')
    infile = open("time_used.txt", "r")
    lines = infile.read()

    file_require_time = int(lines)
    infile.close()
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_time = datetime.datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
    end_time = int(end_time.timestamp())
    infile = open("ip.txt", "r")
    for line in infile:
        strlist = line.split(',')
        # str(input("What's your serve ip?(输入服务器地址)"))
        serveip = str(strlist[0])
        # int(input("What's your serve port?(输入服务器端口)"))
        serveport = int(strlist[1])
        # str(input("What's your login id?(输入用户名)"))
        serve_login_id = str(strlist[2])
        # str(input("What's your login password?(输入密码)"))
        serve_login_password = str(strlist[3])
        ftp = myFtp(serveip, serveport)
        ftp.Login(serve_login_id, serve_login_password)

        file_list = []

        file_list = ftp.time_range_file(file_require_time + 60, strlist[4])
        file_address = strlist[4]
        # download_address =str(input('Where you want to put file in ?文件位置''eg:C:/'))
        download_address = strlist[5]
        print('下载的远程文件为：', file_list)
        if len(file_list) > 0:
            filecreate = 0
            Check_folder = mkdir(
                strlist[5] + '/' + strlist[0] + '/' + ''.join(re.findall(r'[A-Za-z]', strlist[4])))
            while filecreate == 0 and Check_folder == False:
                path = strlist[5] + '/' + strlist[0] + '/' + \
                    ''.join(re.findall(r'[A-Za-z]', strlist[4]))
                shutil.rmtree(path)
                os.makedirs(path)
                filecreate += 1
                Check_folder = True
            for files in file_list:
                path = strlist[5] + '/' + strlist[0] + '/' + \
                    ''.join(re.findall(r'[A-Za-z]', strlist[4]))
                ftp.DownLoadFile(path + '/' + files, files, strlist[4])
            ftp.close()
    infile.close()
    try_exception = True
    while try_exception == True:
        try:
            infile = open("local.txt", "r")
            for line in infile:
                strlist = line.split(',')
                # "D:\\filedownlaod\\"str(input("What's your file address?"))
                filepath = strlist[0]
                file_list = os.listdir(filepath)
                check_folder = 0
                for i in file_list:
                    fixed_time = time.ctime(
                        os.stat(filepath + '/' + i).st_mtime)
                    fixed_time = datetime.datetime.strptime(
                        fixed_time, "%a %b %d %H:%M:%S %Y")
                    fixed_time = int(fixed_time.timestamp())
                    if end_time - fixed_time <= file_require_time:
                        Check_folder = mkdir(
                            strlist[1] + "/" + ''.join(re.findall(r'[A-Za-z]', strlist[0])))
                        if Check_folder == False and check_folder == 0:
                            path = strlist[1] + "/" + \
                                ''.join(re.findall(r'[A-Za-z]', strlist[0]))
                            shutil.rmtree(path)
                            os.makedirs(path)
                            check_folder += 1
                        local.copyfile(strlist[0] + '/' + i,
                                       strlist[1] + "/" + ''.join(re.findall(r'[A-Za-z]', strlist[0])))
            infile.close()
            try_exception = False
        except Exception as msg:
            print("Error - ", msg)
            try_exception = False
        os.system('pause')


def changefilename():  # 修改文件名函数
    infile = open("local.txt", "r")  # 修改本地日志文件名,以只读方式打开本地文件；
    for line in infile:
        strlist = line.split(',')
        path = strlist[0]
        file_list = os.listdir(path)
        check_folder = 0
        for i in file_list:
            fixed_time = time.ctime(os.stat(path + '/' + i).st_mtime)
            fixed_time = datetime.datetime.strptime(
                fixed_time, "%a %b %d %H:%M:%S %Y")
            fixed_time = int(fixed_time.timestamp())
            end_time = int(time.time())
            file_require_time = 3  # 定义获取本地*秒内有修改的日志
            # print(end_time-fixed_time)#输出‘开始’时间与文件修改时间的差值，时间戳格式
            if end_time - fixed_time <= file_require_time:  # 如果文件*秒内有修改，就把文件改名:加前缀打断点，
                renamecheck = False
                if os.path.isdir(i) == True:
                    pass
                elif renamecheck == False:
                    try:
                        os.rename(path + '/' + i, path + '/bp' + i)
                    except:
                        os.rename(path + '/' + i, path +
                                  '/bp(' + str(random.randint(1, 999)) + ')' + i)
                print('给最新的日志文件改名：加前缀、打断点!')
    infile.close()
    infile = open("ip.txt", "r")  # 修改远程日志文件名
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_time = datetime.datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
    end_time = int(end_time.timestamp())
    for line in infile:
        strlist = line.split(',')
        serveip = strlist[0]  # str(input("What's your serve ip?(输入服务器地址)"))
        # int(input("What's your serve port?(输入服务器端口)"))
        serveport = int(strlist[1])
        # str(input("What's your login id?(输入用户名)"))
        serve_login_id = strlist[2]
        # str(input("What's your login password?(输入密码)"))
        serve_login_password = strlist[3]
        ftp = myFtp(serveip, serveport)
        ftp.Login(serve_login_id, serve_login_password)

        file_list = []
        file_list = ftp.time_range_file(60, strlist[4])
        print('操作的远程日志文件为：', file_list)
        for file in file_list:
            path = strlist[4] + '/' + file
            # 如果远程目标路径是目录则不改名，是文件才改名
            if os.path.isdir(path) == True:
                return 0
            try:
                ftp.changename(file, 'bp' + file)
            except:
                ftp.changename(
                    file, 'bp(' + str(random.randint(1, 999)) + ')' + file)
    infile.close()


if __name__ == "__main__":
    root = Tk()

    logframe = Log_catch_GUI(root)
    root.mainloop()
